import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { DndContext, DragEndEvent, closestCenter, DragStartEvent, DragOverEvent, DragOverlay } from "@dnd-kit/core";
import { SortableContext, horizontalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Plus, Wifi, WifiOff, GripVertical, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { LeadCard } from "@/components/funil/LeadCard";
import { DroppableColumn } from "@/components/funil/DroppableColumn";
import { NovoLeadDialog } from "@/components/funil/NovoLeadDialog";
import { AdicionarLeadExistenteDialog } from "@/components/funil/AdicionarLeadExistenteDialog";
import { NovoFunilDialog } from "@/components/funil/NovoFunilDialog";
import { EditarFunilDialog } from "@/components/funil/EditarFunilDialog";
import { AdicionarEtapaDialog } from "@/components/funil/AdicionarEtapaDialog";
import { toast } from "sonner";
import { useGlobalSync } from "@/hooks/useGlobalSync";
import { useWorkflowAutomation } from "@/hooks/useWorkflowAutomation";

interface Lead {
  id: string;
  nome: string;
  name: string;
  company?: string;
  value?: number;
  telefone?: string;
  email?: string;
  cpf?: string;
  source?: string;
  notes?: string;
  etapa_id?: string;
  funil_id?: string;
  created_at?: string;
  updated_at?: string;
}

interface Etapa {
  id: string;
  nome: string;
  posicao: number;
  cor: string;
  funil_id: string;
}

interface Funil {
  id: string;
  nome: string;
  descricao?: string;
}

// Componente para coluna ordenável
/**
 * ✅ BACKUP ATUALIZADO - 2024-11-01
 * IMPORTANTE: Deve ter data: { type: 'etapa' } no useSortable para identificar drag de etapas
 * Se retroceder, verificar se tem data: { type: 'etapa' }
 */
function SortableColumn({
  id,
  children,
  isDragging
}: {
  id: string;
  children: React.ReactNode;
  isDragging?: boolean;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: sortableIsDragging,
  } = useSortable({ id, data: { type: 'etapa' } }); // ✅ CRÍTICO: data: { type: 'etapa' } para identificar drag de etapas

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: transition || 'transform 200ms ease',
    opacity: (sortableIsDragging || isDragging) ? 0.6 : 1,
    scale: (sortableIsDragging || isDragging) ? 0.95 : 1,
    boxShadow: (sortableIsDragging || isDragging) ? '0 10px 30px rgba(0,0,0,0.2)' : 'none',
  };

  return (
    <div ref={setNodeRef} style={style} className="min-w-[320px] flex-shrink-0 relative group">
      {/* Drag handle */}
      <div
        {...attributes}
        {...listeners}
        className="absolute -top-2 -left-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity cursor-grab active:cursor-grabbing"
      >
        <div className="bg-background border rounded-full p-1 shadow-md">
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
      {children}
    </div>
  );
}

export default function KanbanPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [etapas, setEtapas] = useState<Etapa[]>([]);
  const [funis, setFunis] = useState<Funil[]>([]);
  const [selectedFunil, setSelectedFunil] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(true);
  const [dragOperation, setDragOperation] = useState<{
    isDragging: boolean;
    leadId: string | null;
    sourceEtapa: string | null;
  }>({
    isDragging: false,
    leadId: null,
    sourceEtapa: null,
  });
  const [leadsPerEtapa, setLeadsPerEtapa] = useState<Record<string, number>>({});
  const [activeColumn, setActiveColumn] = useState<Etapa | null>(null);
  const LEADS_PER_PAGE = 10;
  const isMovingRef = useRef(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let mounted = true;

    const loadData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Carregar funis
        const { data: funisData, error: funisError } = await supabase
          .from("funis")
          .select("*")
          .order("criado_em");

        if (funisError) throw funisError;

        if (!mounted) return;

        // Atualizar funis
        const loadedFunis = funisData || [];
        setFunis(loadedFunis);

        // Selecionar primeiro funil se necessário
        if (loadedFunis.length > 0 && !selectedFunil) {
          setSelectedFunil(loadedFunis[0].id);
        }

        // Carregar etapas
        const { data: etapasData, error: etapasError } = await supabase
          .from("etapas")
          .select("*")
          .order("posicao");

        if (etapasError) throw etapasError;
        if (!mounted) return;

        setEtapas(etapasData || []);

        // Carregar leads
        const { data: leadsData, error: leadsError } = await supabase
          .from("leads")
          .select("*")
          .order("created_at", { ascending: false });

        if (leadsError) throw leadsError;
        if (!mounted) return;

        setLeads((leadsData || []).map(lead => ({
          ...lead,
          nome: lead.name || "",
          name: lead.name || ""
        })));

      } catch (err: any) {
        console.error("Erro ao carregar dados:", err);
        if (mounted) {
          setError(err.message || "Erro ao carregar dados");
          toast.error("Erro ao carregar funil de vendas");
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      mounted = false;
    };
  }, [selectedFunil]);

  // Atualiza apenas os leads sem recarregar a página
  const refreshLeads = async () => {
    try {
      const { data: leadsData, error: leadsError } = await supabase
        .from("leads")
        .select("*")
        .order("created_at", { ascending: false });
      if (leadsError) throw leadsError;
      setLeads((leadsData || []).map(lead => ({
        ...lead,
        nome: lead.name || "",
        name: lead.name || ""
      })));
    } catch (err) {
      console.error("Erro ao atualizar leads:", err);
    }
  };

  // Atualiza funis
  const refreshFunis = async () => {
    try {
      const { data: funisData, error } = await supabase.from('funis').select('*').order('criado_em');
      if (error) throw error;
      const loaded = funisData || [];
      setFunis(loaded);
      if (!selectedFunil && loaded.length > 0) setSelectedFunil(loaded[0].id);
      if (selectedFunil && !loaded.find(f => f.id === selectedFunil) && loaded.length > 0) {
        setSelectedFunil(loaded[0].id);
      }
    } catch (err) {
      console.error('Erro ao atualizar funis:', err);
    }
  };

  // Atualiza etapas
  const refreshEtapas = async () => {
    try {
      const { data: etapasData, error } = await supabase.from('etapas').select('*').order('posicao');
      if (error) throw error;
      setEtapas(etapasData || []);
    } catch (err) {
      console.error('Erro ao atualizar etapas:', err);
    }
  };

  // Carregar mais leads para uma etapa específica
  const loadMoreLeads = useCallback(async (etapaId: string) => {
    const currentCount = leadsPerEtapa[etapaId] || LEADS_PER_PAGE;
    const newCount = currentCount + LEADS_PER_PAGE;

    setLeadsPerEtapa(prev => ({
      ...prev,
      [etapaId]: newCount
    }));
  }, [leadsPerEtapa, LEADS_PER_PAGE]);

  // Monitorar status de conexão
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success("Conexão restaurada");
    };
    const handleOffline = () => {
      setIsOnline(false);
      toast.error("Sem conexão com a internet");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // useLeadsSync removido aqui para evitar duplicidade com o canal consolidado abaixo

  // Sistema de eventos globais para comunicação entre módulos
  const { emitGlobalEvent } = useGlobalSync({
    callbacks: {
      // Receber eventos de outros módulos
      onLeadUpdated: (data) => {
        console.log('🌍 [Kanban] Lead atualizado via evento global:', data);
        // Atualizar lead se estiver presente no funil atual
        setLeads(prev => prev.map(lead => {
          if (lead.id === data.id) {
            const formattedLead = { ...data, nome: data.name || '', name: data.name || '' };
            return formattedLead;
          }
          return lead;
        }));
      },
      onTaskCreated: (data) => {
        console.log('🌍 [Kanban] Nova tarefa criada, verificar se afeta lead:', data);
        // Se a tarefa estiver vinculada a um lead no funil, podemos atualizar status
        if (data.lead_id) {
          // Opcional: marcar lead como tendo tarefas pendentes
        }
      },
      onMeetingScheduled: (data) => {
        console.log('🌍 [Kanban] Reunião agendada, verificar se afeta lead:', data);
        // Se a reunião estiver vinculada a um lead, podemos atualizar atividade
        if (data.lead_id) {
          // Opcional: marcar lead como tendo reunião agendada
        }
      }
    },
    showNotifications: false
  });

  // Sistema de workflows automatizados
  useWorkflowAutomation({
    showNotifications: true
  });

  // 🎯 Realtime consolidado com gerenciamento robusto
  useEffect(() => {
    let realtimeChannel: any = null;
    let reconnectTimeout: ReturnType<typeof setTimeout> | null = null;
    let reconnectAttempts = 0;
    const MAX_RECONNECT_ATTEMPTS = 5;

    const formatLead = (lead: any): Lead => ({
      ...lead,
      nome: lead.name || '',
      name: lead.name || ''
    });

    const setupRealtimeChannel = () => {
      console.log('🔄 [REALTIME] Configurando canal consolidado...');

      // Canal único para consolidar realtime
      realtimeChannel = supabase
        .channel('kanban_realtime_consolidated')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, (payload: any) => {
          console.log('📡 [REALTIME] Leads:', payload.eventType, payload.new?.id || payload.old?.id);
          
          // Evitar atualizar durante operações de drag
          if (isMovingRef.current) {
            console.log('⏸️ [REALTIME] Ignorando atualização durante drag');
            return;
          }

          if (payload.eventType === 'INSERT') {
            setLeads(prev => {
              // Evitar duplicatas
              if (prev.some(l => l.id === payload.new.id)) return prev;
              return [formatLead(payload.new), ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setLeads(prev => prev.map(l => l.id === payload.new.id ? formatLead(payload.new) : l));
          } else if (payload.eventType === 'DELETE') {
            setLeads(prev => prev.filter(l => l.id !== payload.old.id));
          }
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'etapas' }, (payload: any) => {
          console.log('📡 [REALTIME] Etapas:', payload.eventType);

          // Filtrar mudanças irrelevantes
          if (payload.eventType === 'UPDATE' && payload.new && payload.old) {
            const changedFields = Object.keys(payload.new).filter(key =>
              payload.new[key] !== payload.old[key]
            );

            // Ignorar mudanças apenas de posição ou timestamp
            if (changedFields.length === 1 && (changedFields[0] === 'posicao' || changedFields[0] === 'updated_at')) {
              console.log('⏭️ [REALTIME] Ignorando mudança de posição/timestamp');
              return;
            }
          }

          refreshEtapas();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'funis' }, () => {
          console.log('📡 [REALTIME] Funis atualizados');
          refreshFunis();
        })
        .subscribe((status) => {
          console.log('🔌 [REALTIME] Status:', status);

          if (status === 'SUBSCRIBED') {
            console.log('✅ [REALTIME] Canal conectado com sucesso');
            setIsOnline(true);
            reconnectAttempts = 0;
          } else if (status === 'CHANNEL_ERROR') {
            console.error('❌ [REALTIME] Erro no canal');
            setIsOnline(false);

            // Tentar reconectar automaticamente
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
              reconnectAttempts++;
              const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000); // Backoff exponencial
              
              console.log(`🔄 [REALTIME] Tentando reconectar em ${delay}ms (tentativa ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
              
              reconnectTimeout = setTimeout(() => {
                if (realtimeChannel) {
                  supabase.removeChannel(realtimeChannel);
                }
                setupRealtimeChannel();
              }, delay);
            } else {
              toast.error('Erro na conexão em tempo real', {
                description: 'Recarregue a página para restaurar'
              });
            }
          } else if (status === 'CLOSED') {
            console.log('🔌 [REALTIME] Canal fechado');
            setIsOnline(false);
          }
        });
    };

    setupRealtimeChannel();

    return () => {
      console.log('🧹 [REALTIME] Limpando canal...');
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (realtimeChannel) supabase.removeChannel(realtimeChannel);
    };
  }, [selectedFunil]);

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const leadId = active.id as string;
    const lead = leads.find(l => l.id === leadId);

    setDragOperation({
      isDragging: true,
      leadId,
      sourceEtapa: lead?.etapa_id || null,
    });

    console.log('[DRAG START] Iniciando drag:', { leadId, sourceEtapa: lead?.etapa_id });
  };

  const handleDragOver = (event: DragOverEvent) => {
    // Pode ser usado para feedback visual durante o drag
    const { over } = event;
    if (over) {
      console.log('[DRAG OVER] Hover sobre:', over.id);
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    console.log('[DRAG END] 🎯 Iniciando operação de drag:', { 
      activeId: active.id, 
      overId: over?.id,
      activeType: active.data.current?.type,
      overType: over?.data.current?.type 
    });

    // 🔒 Prevenir operações concorrentes de drag
    if (isMovingRef.current) {
      console.warn('[DRAG END] ⚠️ Operação de drag já em andamento - bloqueado');
      toast.warning("Aguarde a operação anterior finalizar");
      return;
    }

    try {
      // 🧹 Reset drag states
      setDragOperation({
        isDragging: false,
        leadId: null,
        sourceEtapa: null,
      });
      setActiveColumn(null);

      // ✅ Validação básica - sem destino
      if (!over) {
        console.log('[DRAG END] ❌ Drag cancelado - nenhum destino válido');
        return;
      }

      // ✅ Validação de conectividade
      if (!isOnline) {
        console.error('[DRAG END] 🌐 Sem conexão com internet');
        toast.error("Sem conexão - operação não pode ser realizada", {
          description: "Verifique sua conexão e tente novamente"
        });
        return;
      }

      const activeData = active.data.current;
      const overData = over.data.current;

      // 🔀 FLUXO 1: Reordenação de etapas (drag horizontal)
      if (activeData?.type === 'etapa') {
        console.log('[DRAG END] 🔄 Detectado drag de etapa - reordenação');
        await handleEtapaReorder(active.id as string, over.id as string);
        return;
      }

      // 🎯 FLUXO 2: Movimentação de lead entre etapas
      const leadId = active.id as string;

      // 🔍 Determinar etapa de destino com lógica clara
      let newEtapaId: string | null = null;
      
      if (overData?.type === 'etapa') {
        // Drop direto na área da coluna
        newEtapaId = over.id as string;
      } else if (overData?.etapaId) {
        // Drop sobre um lead (pegar etapa desse lead)
        newEtapaId = overData.etapaId as string;
      } else if (overData?.type === 'lead' && overData?.lead?.etapa_id) {
        // Drop sobre lead com etapa definida
        newEtapaId = overData.lead.etapa_id;
      }

      // ✅ Validar etapa de destino
      if (!newEtapaId) {
        console.error('[DRAG END] ❌ Etapa de destino não identificada:', { 
          overData, 
          overId: over.id 
        });
        toast.error("Não foi possível identificar a etapa de destino");
        return;
      }

      // ✅ Validar se o lead existe no estado
      const lead = leads.find(l => l.id === leadId);
      if (!lead) {
        console.error('[DRAG END] ❌ Lead não encontrado no estado local:', leadId);
        toast.error("Lead não encontrado");
        return;
      }

      // ✅ Validar se a etapa de destino existe
      const etapaDestino = etapas.find(e => e.id === newEtapaId);
      if (!etapaDestino) {
        console.error('[DRAG END] ❌ Etapa de destino não existe:', newEtapaId);
        toast.error("Etapa de destino não existe");
        return;
      }

      // ✅ Validar se está tentando mover entre funis diferentes
      if (etapaDestino.funil_id !== selectedFunil) {
        console.error('[DRAG END] ⚠️ Tentativa de mover entre funis diferentes:', {
          etapaFunilId: etapaDestino.funil_id,
          funilSelecionado: selectedFunil
        });
        toast.error("Não é possível mover leads entre funis diferentes", {
          description: "Use a opção 'Mover para outro funil' no menu do lead"
        });
        return;
      }

      // ✅ Verificar se já está na mesma etapa (movimento desnecessário)
      if (lead.etapa_id === newEtapaId) {
        console.log('[DRAG END] ℹ️ Lead já está na etapa destino - ignorando');
        return;
      }

      // 💾 Guardar estado original para rollback em caso de erro
      const originalEtapaId = lead.etapa_id;
      const originalFunilId = lead.funil_id;
      const etapaOrigem = etapas.find(e => e.id === originalEtapaId);

      console.log('[DRAG END] ✅ Validações OK - iniciando movimentação:', {
        leadId,
        leadNome: lead.name,
        de: etapaOrigem?.nome || 'sem etapa',
        para: etapaDestino.nome,
        funilId: etapaDestino.funil_id
      });

      // 🎨 Atualizar UI imediatamente (otimistic update)
      setLeads(currentLeads =>
        currentLeads.map(l =>
          l.id === leadId
            ? { ...l, etapa_id: newEtapaId, funil_id: etapaDestino.funil_id }
            : l
        )
      );

      // 🔒 Bloquear novas operações
      isMovingRef.current = true;

      // 💾 Atualizar no banco de dados
      const { error } = await supabase
        .from("leads")
        .update({
          etapa_id: newEtapaId,
          funil_id: etapaDestino.funil_id,
          stage: etapaDestino.nome.toLowerCase(),
          updated_at: new Date().toISOString()
        })
        .eq("id", leadId);

      if (error) {
        console.error('[DRAG END] ❌ Erro na atualização do banco:', error);
        throw error;
      }

      console.log('[DRAG END] ✅ Lead movido com sucesso no banco');
      toast.success(`Lead movido para "${etapaDestino.nome}"`, {
        description: `${lead.name} foi movido com sucesso`
      });

      // 🌍 Emitir evento global para sincronização com outros módulos
      emitGlobalEvent({
        type: 'funnel-stage-changed',
        data: {
          leadId: leadId,
          leadName: lead.name,
          oldStage: etapaOrigem?.nome || 'sem etapa',
          newStage: etapaDestino.nome,
          funilId: etapaDestino.funil_id,
          etapaId: newEtapaId
        },
        source: 'Funil'
      });

    } catch (error: any) {
      console.error('[DRAG END] ❌ Erro crítico ao mover lead:', error);

      // 🎯 Determinar mensagem de erro específica e útil
      let errorTitle = "Erro ao mover lead";
      let errorDescription = "Tente novamente";

      if (error?.code === 'PGRST116') {
        errorTitle = "Lead não encontrado no servidor";
        errorDescription = "O lead pode ter sido deletado";
      } else if (error?.code === '23503') {
        errorTitle = "Erro de referência";
        errorDescription = "Etapa ou funil inválido";
      } else if (error?.message?.includes('network') || !navigator.onLine) {
        errorTitle = "Erro de conexão";
        errorDescription = "Verifique sua internet";
      } else if (error?.message) {
        errorDescription = error.message;
      }

      toast.error(errorTitle, { description: errorDescription });

      // 🔄 Reverter mudança local (rollback)
      const leadId = event.active.id as string;
      const lead = leads.find(l => l.id === leadId);
      
      if (lead) {
        const originalEtapaId = dragOperation.sourceEtapa;
        const originalFunilId = lead.funil_id;

        console.log('[DRAG END] 🔄 Revertendo mudança local:', {
          leadId,
          revertendoPara: originalEtapaId
        });

        setLeads(currentLeads =>
          currentLeads.map(l =>
            l.id === leadId
              ? { ...l, etapa_id: originalEtapaId, funil_id: originalFunilId }
              : l
          )
        );
      }
    } finally {
      // 🔓 Liberar bloqueio de operações
      isMovingRef.current = false;
    }
  };

  // 🎯 Calcular dados das etapas com useMemo para otimização
  const etapasFiltradas = useMemo(() =>
    etapas.filter((etapa) => etapa.funil_id === selectedFunil),
    [etapas, selectedFunil]
  );

  // 🎯 Pré-calcular totais e métricas avançadas de todas as etapas de uma vez (mais eficiente)
  const etapaStats = useMemo(() => {
    const stats: Record<string, { 
      total: number; 
      count: number; 
      leads: Lead[];
      valorMedio: number;
      taxaConversao: number;
      tempoMedio: number;
    }> = {};
    
    etapasFiltradas.forEach((etapa, index) => {
      const leadsNaEtapa = leads.filter(l => l.etapa_id === etapa.id);
      const total = leadsNaEtapa.reduce((sum, lead) => sum + (lead.value || 0), 0);
      const count = leadsNaEtapa.length;
      
      // 📊 Valor médio por lead
      const valorMedio = count > 0 ? total / count : 0;
      
      // 📈 Taxa de conversão (quantos leads avançaram para próxima etapa)
      let taxaConversao = 0;
      if (index < etapasFiltradas.length - 1) {
        const proximaEtapa = etapasFiltradas[index + 1];
        const leadsProximaEtapa = leads.filter(l => l.etapa_id === proximaEtapa.id).length;
        taxaConversao = count > 0 ? (leadsProximaEtapa / count) * 100 : 0;
      }
      
      // ⏱️ Tempo médio na etapa (simulado - em produção viria do histórico)
      // Por enquanto, vamos calcular com base na idade dos leads
      const tempoMedio = leadsNaEtapa.length > 0
        ? leadsNaEtapa.reduce((sum, lead) => {
            const createdAt = new Date(lead.created_at || Date.now());
            const now = new Date();
            const dias = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24));
            return sum + dias;
          }, 0) / leadsNaEtapa.length
        : 0;
      
      stats[etapa.id] = {
        total,
        count,
        leads: leadsNaEtapa,
        valorMedio,
        taxaConversao,
        tempoMedio
      };
    });
    
    return stats;
  }, [etapasFiltradas, leads]);

  // 🎯 Função otimizada para obter total de uma etapa
  const calcularTotalEtapa = useCallback((etapaId: string) => {
    return etapaStats[etapaId]?.total || 0;
  }, [etapaStats]);

  // 🎯 Função otimizada para obter quantidade de leads em uma etapa
  const getQuantidadeLeads = useCallback((etapaId: string) => {
    return etapaStats[etapaId]?.count || 0;
  }, [etapaStats]);

  // 🎯 Função otimizada para obter leads de uma etapa
  const getLeadsEtapa = useCallback((etapaId: string) => {
    return etapaStats[etapaId]?.leads || [];
  }, [etapaStats]);

  // 🎯 Navegação horizontal suave
  const scrollHorizontal = useCallback((direction: 'left' | 'right') => {
    if (!scrollContainerRef.current) return;
    
    const container = scrollContainerRef.current;
    const scrollAmount = 340; // Largura da coluna + gap
    const targetScroll = direction === 'left' 
      ? container.scrollLeft - scrollAmount 
      : container.scrollLeft + scrollAmount;
    
    container.scrollTo({
      left: targetScroll,
      behavior: 'smooth'
    });
  }, []);

  // Função para reordenar etapas
  const handleEtapaReorder = useCallback(async (activeId: string, overId: string) => {
    if (activeId === overId) return;

    console.log('[REORDER] Iniciando reordenação:', { activeId, overId });

    const activeIndex = etapasFiltradas.findIndex(etapa => etapa.id === activeId);
    const overIndex = etapasFiltradas.findIndex(etapa => etapa.id === overId);

    if (activeIndex === -1 || overIndex === -1) {
      console.error('[REORDER] Índices não encontrados:', { activeIndex, overIndex });
      return;
    }

    // Criar nova ordem das etapas
    const reorderedEtapas = [...etapasFiltradas];
    const [movedEtapa] = reorderedEtapas.splice(activeIndex, 1);
    reorderedEtapas.splice(overIndex, 0, movedEtapa);

    console.log('[REORDER] Nova ordem:', reorderedEtapas.map(e => e.nome));

    // Atualizar posições no estado local primeiro
    const updatedEtapas = reorderedEtapas.map((etapa, index) => ({
      ...etapa,
      posicao: index + 1
    }));

    // Atualizar estado local
    setEtapas(prev =>
      prev.map(etapa =>
        etapa.funil_id === selectedFunil
          ? updatedEtapas.find(e => e.id === etapa.id) || etapa
          : etapa
      )
    );

    try {
      // ✅ BACKUP ATUALIZADO - 2024-11-01: Tenta RPC primeiro, fallback para updates individuais
      // Desabilitar temporariamente o realtime para evitar conflitos
      console.log('[REORDER] Iniciando reordenação - desabilitando realtime temporariamente');

      // ✅ Tentar usar RPC se existir (mais eficiente)
      let rpcError = null;
      if (selectedFunil) {
        try {
          const { error: rpcErr } = await supabase.rpc('reorder_etapas', {
            p_funil_id: selectedFunil,
            p_order: updatedEtapas.map(etapa => etapa.id)
          });
          if (rpcErr) {
            console.warn('[REORDER] RPC reorder_etapas não disponível, usando updates individuais:', rpcErr);
            rpcError = rpcErr;
          } else {
            console.log('[REORDER] Etapas reordenadas com sucesso via RPC');
            toast.success('Etapas reordenadas com sucesso');
            return; // Sucesso via RPC, não precisa fazer updates individuais
          }
        } catch (e) {
          console.warn('[REORDER] RPC reorder_etapas não disponível, usando updates individuais');
          rpcError = e;
        }
      }

      // ✅ CRÍTICO: Fallback para updates individuais - NÃO REMOVER
      // ✅ IMPORTANTE: Usa campo atualizado_em (NÃO updated_at)
      const updates = updatedEtapas.map(etapa => ({
        id: etapa.id,
        posicao: etapa.posicao,
        atualizado_em: new Date().toISOString() // ✅ CRÍTICO: atualizado_em não updated_at
      }));

      // Executar todas as atualizações em paralelo para ser mais rápido
      const updatePromises = updates.map(update =>
        supabase
          .from('etapas')
          .update({
            posicao: update.posicao,
            atualizado_em: update.atualizado_em // ✅ CRÍTICO: atualizado_em não updated_at
          })
          .eq('id', update.id)
      );

      const results = await Promise.all(updatePromises);

      // Verificar se todas as atualizações foram bem-sucedidas
      const errors = results.filter(result => result.error);
      if (errors.length > 0) {
        console.error('[REORDER] Erros nas atualizações:', errors);
        throw new Error('Erro ao atualizar posições das etapas');
      }

      console.log('[REORDER] Etapas reordenadas com sucesso no banco');
      toast.success('Etapas reordenadas com sucesso');

    } catch (error) {
      console.error('[REORDER] Erro ao reordenar etapas:', error);
      toast.error('Erro ao reordenar etapas - revertendo mudanças');

      // Reverter mudanças locais em caso de erro
      await refreshEtapas();
    }
  }, [etapasFiltradas, selectedFunil]);

  const funilSelecionado = funis.find(f => f.id === selectedFunil);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Funil de Vendas</h1>
            <p className="text-muted-foreground">Gerencie seus leads por etapas</p>
          </div>
        </div>
        <div className="flex items-center justify-center min-h-[500px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
            <p className="text-muted-foreground">Carregando funil de vendas...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Funil de Vendas</h1>
            <p className="text-muted-foreground">Gerencie seus leads por etapas</p>
          </div>
        </div>
        <div className="flex items-center justify-center min-h-[500px]">
          <div className="text-center">
            <p className="text-red-500 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()}>
              Tentar Novamente
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!funis || funis.length === 0) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Funil de Vendas</h1>
            <p className="text-muted-foreground">Gerencie seus leads por etapas</p>
          </div>
          <NovoFunilDialog onFunilCreated={() => window.location.reload()} />
        </div>
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">Nenhum funil criado ainda</p>
          <NovoFunilDialog onFunilCreated={() => window.location.reload()} />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      {/* Header com indicador de conexão */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            Funil de Vendas
            {isOnline ? (
              <Wifi className="h-5 w-5 text-green-500" />
            ) : (
              <WifiOff className="h-5 w-5 text-red-500" />
            )}
          </h1>
          <p className="text-muted-foreground">
            Gerencie seus leads por etapas • {isOnline ? 'Online' : 'Offline'}
          </p>
        </div>
        <div className="flex gap-2">
          <NovoFunilDialog onFunilCreated={async () => { await refreshFunis(); await refreshEtapas(); }} />
          <NovoLeadDialog
            onLeadCreated={refreshLeads}
            triggerButton={
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Lead
              </Button>
            }
          />
          {funilSelecionado && etapasFiltradas.length > 0 && (
            <AdicionarLeadExistenteDialog
              funilId={funilSelecionado.id}
              etapaInicial={{ id: etapasFiltradas[0].id, nome: etapasFiltradas[0].nome }}
              onLeadAdded={refreshLeads}
            />
          )}
        </div>
      </div>

      <div className="mb-6 flex items-center gap-3">
        <div className="flex-1 max-w-xs">
          <Label>Funil</Label>
          <select
            value={selectedFunil}
            onChange={(e) => setSelectedFunil(e.target.value)}
            className="w-full p-2 border rounded-md mt-2"
          >
            {funis.map((funil) => (
              <option key={funil.id} value={funil.id}>{funil.nome}</option>
            ))}
          </select>
        </div>
        {funilSelecionado && (
          <div className="mt-6 flex gap-2">
            <AdicionarEtapaDialog
              funilId={funilSelecionado.id}
              onEtapaAdded={async () => { await refreshEtapas(); }}
            />
            <EditarFunilDialog
              funilId={funilSelecionado.id}
              funilNome={funilSelecionado.nome}
              onFunilUpdated={async () => { await refreshFunis(); await refreshEtapas(); }}
            />
          </div>
        )}
        {/* 🎯 Botões de navegação horizontal */}
        {etapasFiltradas.length > 3 && (
          <div className="mt-6 flex gap-2 ml-auto">
            <Button
              variant="outline"
              size="icon"
              onClick={() => scrollHorizontal('left')}
              title="Rolar para esquerda"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => scrollHorizontal('right')}
              title="Rolar para direita"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <DndContext
        collisionDetection={closestCenter}
        onDragStart={(event) => {
          const { active } = event;
          const activeData = active.data.current;

          // Verificar se estamos arrastando uma etapa
          if (activeData?.type === 'etapa') {
            const etapa = etapasFiltradas.find(e => e.id === active.id);
            setActiveColumn(etapa || null);
          } else {
            handleDragStart(event);
          }
        }}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <SortableContext items={etapasFiltradas.map(e => e.id)} strategy={horizontalListSortingStrategy}>
          <div 
            ref={scrollContainerRef}
            className="flex overflow-x-auto gap-4 pb-4 min-h-[600px] scrollbar-thin scrollbar-thumb-primary/30 scrollbar-track-muted/20 hover:scrollbar-thumb-primary/50 snap-x snap-mandatory scroll-smooth"
          >
            {etapasFiltradas.map((etapa, index) => {
            // 🎯 Usar funções otimizadas pré-calculadas
            const totalEtapa = calcularTotalEtapa(etapa.id);
            const quantidadeLeads = getQuantidadeLeads(etapa.id);
            const leadsNaEtapa = getLeadsEtapa(etapa.id);
            const maxLeadsToShow = leadsPerEtapa[etapa.id] || LEADS_PER_PAGE;
            const leadsToShow = leadsNaEtapa.slice(0, maxLeadsToShow);
            const hasMoreLeads = leadsNaEtapa.length > maxLeadsToShow;

            return (
                <React.Fragment key={etapa.id}>
                  <SortableColumn
                    id={etapa.id}
                    isDragging={activeColumn?.id === etapa.id}
                  >
                <DroppableColumn
                  id={etapa.id}
                  cor={etapa.cor}
                  nome={etapa.nome}
                  quantidadeLeads={quantidadeLeads}
                  totalEtapa={totalEtapa}
                  valorMedio={etapaStats[etapa.id]?.valorMedio || 0}
                  taxaConversao={etapaStats[etapa.id]?.taxaConversao || 0}
                  tempoMedio={etapaStats[etapa.id]?.tempoMedio || 0}
                  onEtapaUpdated={async () => { await refreshEtapas(); await refreshLeads(); }}
                  isDraggingOver={dragOperation.isDragging && dragOperation.sourceEtapa !== etapa.id}
                >
                  {leadsToShow.map((lead) => (
                    <LeadCard
                      key={lead.id}
                      lead={lead}
                      onDelete={async (id) => {
                        try {
                          // Remover do funil sem deletar o lead (evita falha por relacionamentos)
                          const { error } = await supabase
                            .from("leads")
                            .update({ funil_id: null, etapa_id: null })
                            .eq("id", id);
                          if (error) throw error;

                          setLeads(current => current.filter(l => l.id !== id));
                          toast.success("Lead removido do funil");
                        } catch (error) {
                          console.error("Erro ao remover do funil:", error);
                          toast.error("Erro ao remover do funil");
                        }
                      }}
                      onLeadMoved={refreshLeads}
                      isDragging={dragOperation.isDragging && dragOperation.leadId === lead.id}
                    />
                  ))}

                  {hasMoreLeads && (
                    <div className="text-center py-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => loadMoreLeads(etapa.id)}
                        className="text-xs"
                      >
                        Carregar mais leads ({leadsNaEtapa.length - maxLeadsToShow} restantes)
                      </Button>
                    </div>
                  )}

                  {leadsNaEtapa.length === 0 && (
                    <div className={`text-center py-8 text-muted-foreground text-sm transition-all duration-200 ${
                      dragOperation.isDragging ? 'bg-primary/5 border-2 border-dashed border-primary/30 rounded-lg' : ''
                    }`}>
                      {dragOperation.isDragging ? 'Solte aqui para mover' : 'Arraste leads para cá'}
                    </div>
                  )}
                  </DroppableColumn>
                  </SortableColumn>
                </React.Fragment>
            );
          })}
          </div>
        </SortableContext>

        <DragOverlay>
          {activeColumn ? (
            <div className="min-w-[320px] opacity-90 rotate-3 scale-105">
              <DroppableColumn
                id={activeColumn.id}
                cor={activeColumn.cor}
                nome={activeColumn.nome}
                quantidadeLeads={leads.filter(l => l.etapa_id === activeColumn.id).length}
                totalEtapa={calcularTotalEtapa(activeColumn.id)}
                onEtapaUpdated={() => {}}
                isDraggingOver={false}
              >
                <div className="text-center py-8 text-muted-foreground text-sm">
                  Movendo etapa...
                </div>
              </DroppableColumn>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}